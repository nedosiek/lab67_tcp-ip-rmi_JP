package org.example.client;


public class Main {
    public static void main(String[] args) {
        ClientStart.main(args);
    }
}

